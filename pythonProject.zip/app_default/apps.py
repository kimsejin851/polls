from django.apps import AppConfig


class AppDefaultConfig(AppConfig):
    name = 'app_default'
